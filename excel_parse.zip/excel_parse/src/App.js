import React from 'react'
// import Converter from './components/Converter'
import Upload from './components/Upload'

function App() {
  return (
    <div style={{ display: 'flex' }}>
      <Upload />
      {/* <Converter /> */}
    </div>
  )
}

export default App
